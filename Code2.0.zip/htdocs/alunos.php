<?php

include_once ('connect.php');
$sql = "SELECT * FROM alunos ORDER BY id DESC";
$result = $conexao->query($sql);

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="C:\Users\comer\Desktop\Loui\Code\img\favico.ico" type="image/x-icon">
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="alunos.css">
    <title>Alunos</title>
   
</head>

<body>
    <div class="bgimg">
        <div class="centervid">
        

            <ul>
                <li><a class="home" href="index.html">Home</a></li>
                <li><a href="cadaluno.html">Cadastrar</a></li>
                <li><a href="#">Filtrar</a></li>
                <li style="float: right;"><a class="active" href="#">Login/Logout</a></li>
                <li style="float: right;"><a href="#">Perfil</a></li>
            </ul>
            <div class="m-5" id="m-5">
                <table class="table text-white table-bg">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Nome</th>
                            <th scope="col">Data_Nasc</th>
                            <th scope="col">CPF</th>
                            <th scope="col">telefone</th>
                            <th scope="col">E-mail</th>
                            <th scope="col">Endereço</th>
                            <th scope="col">Nº</th>
                            <th scope="col">Plano</th>
                            <th scope="col">User Type</th>
                            <th scope="col">OBS</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 

                    while($user_data = mysqli_fetch_assoc($result)) {
                        
                        echo  "<tr>";
                        echo "<td>".$user_data['id']."</td>"; 
                        echo "<td>".$user_data['nome']."</td>";
                        echo "<td>".$user_data['data_nasc']."</td>";
                        echo "<td>".$user_data['cpf']."</td>";
                        echo "<td>".$user_data['telefone']."</td>";
                        echo "<td>".$user_data['email']."</td>";
                        echo "<td>".$user_data['endereco']."</td>";
                        echo "<td>".$user_data['numende']."</td>";
                        echo "<td>".$user_data['plano']."</td>";
                        echo "<td>".$user_data['tipoaluno']."</td>";
                        echo "<td>".$user_data['obs']."</td>";
                        
                        echo  "</tr>";
                        
                    }
                    
                    ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
function abrirPopup() {
    // URL que você deseja abrir no popup
    var url = 'http://localhost/public/index.html';
    
    // Abre o popup com a URL
    window.open(url, '_blank', 'width=600,height=400');
}
const cam = document.getElementById('cam');
let isModelsLoaded = false;
let resultado = document.getElementById('reconhecimento');

const startVideo = async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        cam.srcObject = stream;
    } catch (error) {
        console.error('Erro ao acessar a câmera:', error);
    }
};

const loadModels = async () => {
    if (!isModelsLoaded) {
        await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri('/assets/lib/face-api/models'),
            faceapi.nets.faceLandmark68Net.loadFromUri('/assets/lib/face-api/models'),
            faceapi.nets.faceRecognitionNet.loadFromUri('/assets/lib/face-api/models'),
            faceapi.nets.faceExpressionNet.loadFromUri('/assets/lib/face-api/models'),
            faceapi.nets.ageGenderNet.loadFromUri('/assets/lib/face-api/models'),
            faceapi.nets.ssdMobilenetv1.loadFromUri('/assets/lib/face-api/models')
        ]);
        isModelsLoaded = true;
    }
};

// const getImageFiles = async () => {
//     return ['leonam.jpg', 'leonam2.jpg', 'cristina.jpg', 'cristina2.jpg']; 
// };

async function getImageFiles() {
    try {
        const response = await fetch('http://localhost:3000/api/arquivos');  // URL completa para a API
        const arquivos = await response.json();        
        return arquivos;
    } catch (err) {
        console.error('Erro ao buscar arquivos:', err);
        return [];
    }
}


const loadLabels = async () => {
    const imageFiles = await getImageFiles();
    const labeledDescriptors = [];

    for (const file of imageFiles) {
        const img = await faceapi.fetchImage(`/assets/lib/face-api/labels/fotos/${file}`);
        const detections = await faceapi
            .detectSingleFace(img)
            .withFaceLandmarks()
            .withFaceDescriptor();

        if (detections) {
            // Adiciona o descritor com o nome do arquivo
            labeledDescriptors.push(new faceapi.LabeledFaceDescriptors(file, [detections.descriptor]));
        }
    }

    return labeledDescriptors;
};


startVideo();

cam.addEventListener('play', async () => {
    await loadModels(); // Certifique-se de carregar os modelos antes de executar a detecção facial
    const canvas = faceapi.createCanvasFromMedia(cam);
    const canvasSize = { width: cam.width, height: cam.height };
    const labels = await loadLabels();
    faceapi.matchDimensions(canvas, canvasSize);
    document.body.appendChild(canvas);
    setInterval(async () => {
        const detections = await faceapi
            .detectAllFaces(cam, new faceapi.TinyFaceDetectorOptions())
            .withFaceLandmarks()
            .withFaceExpressions()
            .withFaceDescriptors();
        const resizedDetections = faceapi.resizeResults(detections, canvasSize);
        const faceMatcher = new faceapi.FaceMatcher(labels, 0.6);
        const results = resizedDetections.map(d => faceMatcher.findBestMatch(d.descriptor));
        canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
        results.forEach((result, index) => {
            const box = resizedDetections[index].detection.box;
            let { label, distance } = result;
            label = label.replace(/\.jpg$/, '').replace(/2/, '').replace(/unknown/, 'Rosto não reconhecido');            
            
            //new faceapi.draw.DrawTextField([`${label}`], box.bottomRight).draw(canvas); // Faz aparecer na tela o nome reconhecido

            document.getElementById('labelDisplay').innerText = `${label}`;
        });
    }, 300); // Alterei o intervalo para 300ms para reduzir a carga no sistema
});
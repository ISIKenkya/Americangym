<?php

if (!empty($_GET['id'])) {

    include_once ('../assets/php/connect.php');

    $id = $_GET['id'];

    $sqlSelect = "SELECT * FROM alunos WHERE id=$id";

    $result = $conexao->query($sqlSelect);

    if ($result->num_rows > 0) {
        while ($user_data = mysqli_fetch_assoc($result)) {
            $nome = $user_data['nome'];
            $data_nasc = $user_data['data_nasc'];
            $cpf = $user_data['cpf'];
            $telefone = $user_data['telefone'];
            $email = $user_data['email'];
            $endereco = $user_data['endereco'];
            $numende = $user_data['numende'];
            $plano = $user_data['plano'];
            $adicionalplano = $user_data['adicionalplano'];
            $tipoaluno = $user_data['tipoaluno'];
            var_dump($tipoaluno);
            $obs = $user_data['obs'];
        }
    } else {
        header('../alunos/alunos.php');
    }
}


?>
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');  // Importe o middleware CORS

const app = express();
const port = 3000;

// Habilite o CORS
app.use(cors());

// Caminho da pasta que você quer ler
const pasta = path.join(__dirname, 'assets/lib/face-api/labels/fotos');

// Função para ler arquivos e transformar em um array
function lerArquivosNaPasta(pasta) {
    return new Promise((resolve, reject) => {
        fs.readdir(pasta, (err, arquivos) => {
            if (err) {
                reject(err);
            } else {
                resolve(arquivos);
            }
        });
    });
}

// Rota para fornecer os nomes dos arquivos
app.get('/api/arquivos', async (req, res) => {
    try {
        const arquivos = await lerArquivosNaPasta(pasta);
        res.json(arquivos);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao ler a pasta' });
    }
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});

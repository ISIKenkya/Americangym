<?php

include_once ('../assets/php/connect.php');

// Função para normalizar o telefone
function normalize_phone_number($phone) {
    return preg_replace("/[^0-9]/", "", $phone);
}

// Função para normalizar o CPF
function normalize_cpf($cpf) {
    return preg_replace("/[^0-9]/", "", $cpf);
}


// Função para identificar o tipo de termo de pesquisa
function identify_search_type($search) {
    // Normaliza a entrada do telefone
    $normalized_search = normalize_phone_number($search);
    
    // Verifica se o termo é um email
    if (filter_var($search, FILTER_VALIDATE_EMAIL)) {
        return 'email';
    }
    // Verifica se o termo é um telefone
    elseif (preg_match("/^[0-9]{10,11}$/", $normalized_search)) {
        return 'telefone';
    }
    // Verifica se o termo é um CPF
    elseif (preg_match("/^[0-9]{11}$/", $normalized_search) || preg_match("/^[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}$/", $normalized_search)) {
        return 'cpf';
    }
    // Caso contrário, trata como texto
    else {
        return 'text';
    }
}

$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($search) {
    $search_type = identify_search_type($search);
    $cleaned_search = preg_replace("/[^0-9a-zA-Z]/", "", $search);
    
    switch ($search_type) {
        case 'email':
            $sql = "SELECT * FROM alunos WHERE email LIKE ? ORDER BY id DESC";
            $param = "%$search%";
            break;
        case 'telefone':
            $cleaned_search = normalize_phone_number($search);
            $sql = "SELECT * FROM alunos WHERE REPLACE(REPLACE(REPLACE(REPLACE(telefone, '(', ''), ')', ''), '-', ''), ' ', '') LIKE ? ORDER BY id DESC";
            $param = "%$cleaned_search%";
            break;
        case 'cpf':
            $cleaned_search = normalize_cpf($search);
            $sql = "SELECT * FROM alunos WHERE REPLACE(REPLACE(REPLACE(cpf, '.', ''), '-', ''), ' ', '') LIKE ? ORDER BY id DESC";
            $param = "%$cleaned_search%";
            break;
        case 'text':
        default:
            $sql = "SELECT * FROM alunos WHERE nome LIKE ? 
            OR REPLACE(REPLACE(REPLACE(cpf, '.', ''), '-', ''), ' ', '') LIKE ? 
            OR REPLACE(REPLACE(REPLACE(REPLACE(telefone, '(', ''), ')', ''), '-', ''), ' ', '') LIKE ? 
            OR email LIKE ? 
            OR plano LIKE ? 
            OR tipoaluno LIKE ? ORDER BY id DESC";
            $param = "%$search%";
            break;
    }
} else {
    $sql = "SELECT * FROM alunos ORDER BY id DESC";
}

$stmt = $conexao->prepare($sql);

if ($search) {
    if ($search_type === 'text') {
        $stmt->bind_param('ssssss', $param, $param, $param, $param, $param, $param);
    } else {
        $stmt->bind_param('s', $param);
    }
}

$stmt->execute();
$result = $stmt->get_result();

while ($user_data = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $user_data['nome'] . "</td>";
    echo "<td>" . $user_data['data_nasc'] . "</td>";
    echo "<td>" . $user_data['cpf'] . "</td>";
    echo "<td>" . $user_data['telefone'] . "</td>";
    echo "<td>" . $user_data['email'] . "</td>";
    echo "<td>" . $user_data['endereco'] . "</td>";
    echo "<td>" . $user_data['numende'] . "</td>";
    echo "<td>" . $user_data['plano'] . "</td>";
    echo "<td>" . $user_data['adicionalplano'] . "</td>";
    echo "<td>" . $user_data['tipoaluno'] . "</td>";
    echo "<td class='limite'>" . $user_data['obs'] . "</td>";
    echo "<td><a href='../cadaluno/editcadaluno.php?id=" . $user_data['id'] . "'><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-pencil' viewBox='0 0 16 16'><path d='M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325'/></svg></a></td>";
    echo "<td><a href='../cadaluno/deleditcadaluno.php?id=" . $user_data['id'] . "'><svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-trash' viewBox='0 0 16 16'><path d='M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z'/><path d='M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z'/></svg></a></td>";
    echo "</tr>";
    }
    ?>
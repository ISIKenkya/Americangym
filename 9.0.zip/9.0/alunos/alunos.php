<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../img/favico.ico" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="./alunos.css">
    <title>Alunos</title>
</head>

<body>
    <div>
        <section>
            <div class="divnav">
                <nav class="nav_nav">
                    <a class="navbar_a" href="../index.html">Home</a>
                    <a class="navbar_a" href="./alunos.php">Alunos</a>
                    <a class="navbar_a" href="../financeiro/financeiro.html">Financeiro</a>
                    <a class="navbar_a" href="../funcionarios/funcionarios.html">Funcionários</a>
                    <a class="navbar_a" href="../login/login.html">Sair</a>
                </nav>
            </div>
            <a class="button_a" href="../cadaluno/cadaluno.html">Cadastrar</a><br>
            <img class="imgcenter" src="..\img\ag.png">
        </section>
    </div>
    <input type="search">
    <main>
        <div class="pesquisaaluno">
            <input type="search" placeholder="Pesquisar" id="pesquisar">
            <button onclick="searchData()" class="pesquisabtn"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                    class="bi bi-search" viewBox="0 0 16 16">
                    <path
                        d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1
                         1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                </svg></button>
        </div>
        <div class='container'>
            <table class="table_bg">
                <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Data de nascimento</th>
                    <th scope="col">CPF</th>
                    <th scope="col">Telefone</th>
                    <th scope="col">E-mail</th>
                    <th scope="col">Endereço</th>
                    <th scope="col">Nº</th>
                    <th scope="col">Plano</th>
                    <th scope="col">Adicional</th>
                    <th scope="col">Tipo Cadastro</th>
                    <th class="limite" scope="col">OBS</th>
                </tr>
                <?php include('alunosteste.php'); ?>
            </table>
        </div>
    </main>
    <img class="imgcenter" src="..\img\ag.png">
</body>
<script>
var search = document.getElementById('pesquisar');

search.addEventListener("keydown", function(event) {
    if (event.key == "Enter") {
        searchData();
    }
});

function searchData() {
    var search = document.getElementById('pesquisar').value;
    window.location = 'alunos.php?search=' + encodeURIComponent(search);
}
</script>
</html>

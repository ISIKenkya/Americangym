<?php

if (isset($_POST['submit'])){
 
    include_once ('../assets/php/connect.php');

    $nome = $_POST ['nome'];
    $data_nasc = $_POST ['nascimento'];
    $cpf = $_POST ['cpf'];
    $telefone = $_POST ['telefone'];
    $email = $_POST ['email'];
    $endereco = $_POST ['endereco'];
    $numende = $_POST ['numende'];
    $plano = $_POST ['plano'];
    $tipoaluno = $_POST ['tipocadastro'];
    $obs = $_POST ['obscadastro'];

    $result = mysqli_query($conexao, "INSERT INTO alunos(nome,data_nasc,cpf,telefone,email,endereco,numende,plano,tipoaluno,obs)
    VALUES ('$nome','$data_nasc','$cpf','$telefone','$email','$endereco','$numende','$plano','$tipoaluno','$obs')");
}

if(isset($_POST['submit'])){
    
    $nome = $_POST ['nome'];
    $imagemBase64 = $_POST['imagem'];
    $dadosImagem = preg_replace('#^data:image/\w+;base64,#i', '', $imagemBase64);
    $extensao = 'jpg'; // Extensão padrão
    if (strpos($imagemBase64, 'data:image/png') === 0) {
        $extensao = 'png'; // Altera a extensão para PNG se a imagem for PNG
    } 

    $nomeArquivo = $nome . '.' . $extensao;
    $imagemBinaria = base64_decode($dadosImagem);
    file_put_contents('fotos/' . $nomeArquivo, $imagemBinaria);
    echo 'Upload concluído. Imagem salva como: ' . $nomeArquivo;
}

if(isset($_POST['submit'])){
    
    $nome = $_POST ['nome'];
    $imagemBase64 = $_POST['imagem2'];
    $dadosImagem = preg_replace('#^data:image/\w+;base64,#i', '', $imagemBase64);
    $extensao = 'jpg'; // Extensão padrão
    if (strpos($imagemBase64, 'data:image/png') === 0) {
        $extensao = 'png'; // Altera a extensão para PNG se a imagem for PNG
    } 

    $nomeArquivo = $nome . '2.' . $extensao;
    $imagemBinaria = base64_decode($dadosImagem);
    file_put_contents('fotos/' . $nomeArquivo, $imagemBinaria);
    echo 'Upload concluído. Imagem salva como: ' . $nomeArquivo;
}
header("Location: cadaluno.html");
exit;

?>

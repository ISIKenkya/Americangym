document.getElementById('cpf').addEventListener('input', function(event) {
    let cpf = event.target.value.replace(/\D/g, ''); // Remove todos os caracteres que não são dígitos
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Adiciona o ponto após os primeiros três dígitos
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Adiciona o segundo ponto após os próximos três dígitos
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); // Adiciona o hífen e os últimos dois dígitos
    event.target.value = cpf;
});

document.getElementById('tel').addEventListener('input', function(event) {
    let tel = event.target.value.replace(/\D/g, ''); // Remove todos os caracteres que não são dígitos
    tel = tel.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3'); // Formata o telefone
    event.target.value = tel;
});

document.getElementById('numero').addEventListener('input', function(event) {
    let numero = event.target.value.replace(/\D/g, '');
    event.target.value = numero;
});



//daqui pra baixo gpt fez garantir funcionar a camera 


function visualizarFoto() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');

    // Desenha a imagem do vídeo no canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Obtém a imagem do canvas como base64 e a armazena no campo de imagem
    const imagem = canvas.toDataURL('image/png');
    document.getElementById('imagem').value = imagem;
}

function visualizarFoto2() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas2');
    const context = canvas.getContext('2d');

    // Desenha a imagem do vídeo no canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Obtém a imagem do canvas como base64 e a armazena no campo de imagem
    const imagem = canvas.toDataURL('image/png');
    document.getElementById('imagem2').value = imagem;
}
function startCamera() {
    const video = document.getElementById('video');

    // Verifica se o navegador suporta a API de mídia
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // Solicita permissão para acessar a câmera
        navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
            // Se a permissão for concedida, define o srcObject do elemento de vídeo como o fluxo da câmera
            video.srcObject = stream;
            // Inicia o vídeo
            video.play();
        }).catch(function(error) {
            console.error('Erro ao acessar a câmera: ', error);
        });
    } else {
        console.error('Seu navegador não suporta a API de mídia');
    }
}

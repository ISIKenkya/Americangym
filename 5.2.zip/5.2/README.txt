Atualizado:

Cadastro aluno (falta alguns ajustes na responsividade)
Login
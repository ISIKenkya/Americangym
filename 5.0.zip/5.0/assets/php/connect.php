<?php

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'american_gym';

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

?>

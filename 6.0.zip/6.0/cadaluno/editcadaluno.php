<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <link rel="icon" href="C:\Users\comer\Desktop\Loui\Code\img\favico.ico" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="cadaluno.css">
    <title>Cadastrar</title>
</head>
<?php

include_once ('../assets/php/connect.php');
include_once ('editcadaluno1.php');
?>

<body>
    <nav>
        <ul>
            <li><a class="home" href="../index.html">Início</a></li>
            <li><a href="../alunos/alunos.php">Alunos</a></li>
            <li><a href="../financeiro/financeiro.html">Financeiro</a></li>
            <li><a href="../funcionarios/funcionarios.html">Funcionários</a></li>
            <li><a href="../alunos/alunos.php" class="#" name="#" id="#">Voltar</a></li>
            <li><a class="active" href="../assets/php/sair.php">Sair</a></li>
        </ul>
    </nav>

    <main>
        <form id="form-imagem" action="saveeditcadaluno.php" method="POST" enctype="multipart/form-data"
            class="esteticainput">
            <label for="nome">
                <input type="text" name="nome" placeholder="Nome completo" value="<?php echo $nome; ?>" required>
            </label>

            <label for="Nascimento">
                <input type="date" id="Nascimento" name="nascimento" value="<?php echo $data_nasc; ?>" required></input>

            </label>

            <label for="cpf">
                <input type="text" name="cpf" placeholder="CPF" id="cpf" maxlength="14" value="<?php echo $cpf; ?>">
            </label>

            <label for="telefone">
                <input type="tel" id="tel" name="telefone" placeholder="Telefone" maxlength="13"
                    value="<?php echo $telefone; ?>" required>
            </label>

            <label for="email">
                <input type="email" name="email" placeholder="E-mail" value="<?php echo $email; ?>" required>
            </label>

            <div style="display: flex; gap: 10px; width: 100%;">
                <label for="endereco" style="flex: 1;">
                    <input type="text" id="endereco" name="endereco" placeholder="Endereço"
                        value="<?php echo $endereco; ?>" required>
                </label>

                <label for="numero" style="flex: 0 0 80px;">
                    <input type="text" name="numende" id="numero" placeholder="1234" value="<?php echo $numende; ?>"
                        required>
                </label>
            </div>

            <div style="display: flex; gap: 10px; width: 100%;">
                <label for="plano" style="flex: 1;">
                    <select id="plano" name="plano">
                        <?php
                        $planos = array("Mensal", "Trimestral", "Semestral", "Anual");
                        foreach ($planos as $opcao) {
                            echo "<option value=\"$opcao\"";
                            if ($plano == $opcao) {
                                echo " selected";
                            }
                            echo ">$opcao</option>";
                        }
                        ?>
                    </select>
                </label>

                <label class="planoad">+</label>

                <label for="adicionalplano" style="flex: 0 0 80px;">
                    <select id="adicionalplano" name="adicionalplano">
                        <?php
                        for ($i = 0; $i <= 12; $i++) {
                            echo "<option value=\"$i\"";
                            if ($adicionalplano == $i) {
                                echo " selected";
                            }
                            echo ">$i</option>";
                        }
                        ?>
                    </select>
                </label>

                <label for="tipoaluno" style="flex: 1;">
                    <select id="tipoaluno" name="tipoaluno">
                        <?php
                        $tipos = array("Aluno", "Funcionário");
                        foreach ($tipos as $opcao) {
                            echo "<option value=\"$opcao\"";
                            if ($tipoaluno == $opcao) {
                                echo " selected";
                            }
                            echo ">$opcao</option>";
                        }
                        ?>
                    </select>
                </label>
            </div>


            <label for="obscadastro" class="full-width">
                <textarea id="obscadastro" name="obscadastro" placeholder="Obs..." style="resize: none;"
                    required><?php echo $obs; ?></textarea>

            </label>
                        
            <div class="media">
                <button type="button" onclick="startCamera()">Abrir camera</button>
                <button type="button" onclick="visualizarFoto()">Foto 1</button>
                <button type="button" onclick="visualizarFoto2()">Foto 2</button>
                <input type="hidden" id="imagem" name="imagem">
                <input type="hidden" id="imagem2" name="imagem2">
            </div>


            <video id="video" width="200" height="150" autoplay muted></video>

            <canvas width="150" height="150"></canvas>
            <canvas id="canvas" width="200" height="150"></canvas>
            <canvas id="canvas2" width="200" height="150"></canvas>

            <button type="submit" name="update" id="update" class="submit">Cadastrar</button>
            <input type="hidden" name="id" value="<?php echo $id?>">
        </form>
    </main>

    <script src="cadaluno.js"></script>
</body>

</html>
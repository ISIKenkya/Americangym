<?php

include_once('../assets/php/connect.php');

if(isset($_POST['update'])){
    
    $id = $_POST['id'];
    $nome = $_POST ['nome'];
    $data_nasc = $_POST ['nascimento'];
    $cpf = $_POST ['cpf'];
    $telefone = $_POST ['telefone'];
    $email = $_POST ['email'];
    $endereco = $_POST ['endereco'];
    $numende = $_POST ['numende'];
    $plano = $_POST ['plano'];
    $adicionalplano = $_POST ['adicionalplano'];
    $tipoaluno = $_POST ['tipoaluno'];
    $obs = $_POST ['obscadastro'];

    $sqlUpdate = "UPDATE alunos SET nome ='$nome', data_nasc='$data_nasc', cpf='$cpf', telefone='$telefone', email='$email', 
    endereco='$endereco', numende = '$numende', plano = '$plano', adicionalplano='$adicionalplano', tipoaluno = '$tipoaluno', 
    obs ='$obs' WHERE id='$id'";

    $result = $conexao->query($sqlUpdate);
}
header('Location: ../alunos/alunos.php');


if(isset($_POST['update'])){
    
    $nome = $_POST ['nome'];
    $imagemBase64 = $_POST['imagem'];
    $dadosImagem = preg_replace('#^data:image/\w+;base64,#i', '', $imagemBase64);
    $extensao = 'jpg'; // Extensão padrão
    if (strpos($imagemBase64, 'data:image/png') === 0) {
        $extensao = 'png'; // Altera a extensão para PNG se a imagem for PNG
    } 

    $nomeArquivo = $nome . '.' . $extensao;
    $imagemBinaria = base64_decode($dadosImagem);
    file_put_contents('fotos/' . $nomeArquivo, $imagemBinaria);
    echo 'Upload concluído. Imagem salva como: ' . $nomeArquivo;
}

if(isset($_POST['update'])){
    
    $nome = $_POST ['nome'];
    $imagemBase64 = $_POST['imagem2'];
    $dadosImagem = preg_replace('#^data:image/\w+;base64,#i', '', $imagemBase64);
    $extensao = 'jpg'; // Extensão padrão
    if (strpos($imagemBase64, 'data:image/png') === 0) {
        $extensao = 'png'; // Altera a extensão para PNG se a imagem for PNG
    } 

    $nomeArquivo = $nome . '2.' . $extensao;
    $imagemBinaria = base64_decode($dadosImagem);
    file_put_contents('fotos/' . $nomeArquivo, $imagemBinaria);
    echo 'Upload concluído. Imagem salva como: ' . $nomeArquivo;
}
header("Location: ../alunos/alunos.php");
exit;

?>

// Inicializa a webcam
navigator.mediaDevices.getUserMedia({ video: true })
    .then(function (stream) {
        var video = document.getElementById('video');
        video.srcObject = stream;
        video.play();
    })
    .catch(function (err) {
        console.error('Erro ao acessar a webcam: ', err);
    });

var video = document.getElementById('video');
var canvas = document.getElementById('canvas');
var canvas2 = document.getElementById('canvas2');
var context = canvas.getContext('2d');
var context2 = canvas2.getContext('2d');

video.addEventListener('canplay', function () {
    console.log('Video pronto');
});

function visualizarFoto() {
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        var imagemBase64 = canvas.toDataURL('image/jpeg'); // Converte o canvas para base64
        document.getElementById('imagem').value = imagemBase64; // Define o valor do campo hidden
    } 
    else {
        setTimeout(visualizarFoto, 100);
    }
}

function visualizarFoto2() {
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
        context2.drawImage(video, 0, 0, canvas2.width, canvas2.height);
        var imagemBase64 = canvas2.toDataURL('image/jpeg'); // Converte o canvas para base64
        document.getElementById('imagem2').value = imagemBase64; // Define o valor do campo hidden
    } 
    else {
        setTimeout(visualizarFoto, 100);
    }
}